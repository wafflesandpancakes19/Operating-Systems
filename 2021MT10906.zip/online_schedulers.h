#pragma once

//Can include any other headers as needed
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/time.h>
#include <stdbool.h>
#include <string.h>
#include <fcntl.h>
#include <stdint.h>
#include <time.h>
#include <errno.h>


typedef struct {

    //This will be given by the tester function this is the process command to be scheduled
    char *command;

    //Temporary parameters for your usage can modify them as you wish
    bool finished;  //If the process is finished safely
    bool error;    //If an error occurs during execution
    uint64_t start_time;
    uint64_t completion_time;
    uint64_t turnaround_time;
    uint64_t waiting_time;
    uint64_t response_time;
    uint64_t burst_time;
    uint64_t arrival_time;
    uint64_t remaining_time;
    pid_t pid; // process id for the command that has been running (in order to resume the process)
    bool started; 
    int process_id;
    int occurrences;
    bool is_default;

} Process;

volatile sig_atomic_t interrupted = 0;

// Function prototypes
void ShortestJobFirst();
void MultiLevelFeedbackQueue(int quantum0, int quantum1, int quantum2, int boostTime);

// Function to get current time in milliseconds
uint64_t find_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

void run_process(Process *process) {
    printf("Running command: %s\n", process->command);
    
    // Fork a new process
    process->pid = fork();
    if (process->pid == 0) {
        // Child process runs the command
        execl("/bin/sh", "sh", "-c", process->command, (char *)NULL);
        perror("execl failed");
        exit(EXIT_FAILURE);
    }
    
    int status;
    uint64_t start_time = find_time();
    waitpid(process->pid, &status, 0);
    uint64_t end_time = find_time();
    
    uint64_t elapsed_time = end_time - start_time;

    // Update burst time using historical data (excluding errors)
    if (WIFEXITED(status) && WEXITSTATUS(status) == EXIT_SUCCESS) {
        process->finished = true;
        process->error = false;
        
        // Update burst time (average with historical burst time)
        if (process->occurrences == 0) {
            process->burst_time = elapsed_time;
        } else {
            process->burst_time = ((process->burst_time * process->occurrences) + elapsed_time) / (process->occurrences + 1);
        }
        process->occurrences++;
    } else {
        process->finished = true;
        process->error = true;
    }

    // Update timing metrics
    process->completion_time = find_time() - process->arrival_time;
    process->turnaround_time = process->completion_time;
    process->waiting_time = process->turnaround_time - process->burst_time;
    
    process->pid = 0;  // Reset pid after the process finishes
}


void run_process2(Process *process, uint64_t time_slice, int is_slice) {
    printf("Running command: %s\n", process->command);
    printf("Time slice: %lu ms\n", time_slice);
    fflush(stdout);

    // Initialize remaining time if not set
    if (process->remaining_time == 0) {
        process->remaining_time = 1000;  // Default to 1 second if not known
        process->is_default = true;
        printf("Initial remaining time set to default: 1000 ms\n");
    }

    uint64_t allotted_slice = (process->remaining_time > 0 && process->remaining_time < time_slice)
                              ? process->remaining_time : time_slice;

    if (process->pid == 0) {
        // Fork a new process if not already running
        process->pid = fork();

        if (process->pid == 0) {
            // Child process runs the command
            execl("/bin/sh", "sh", "-c", process->command, (char *)NULL);
            perror("execl failed");  // Print specific error
            exit(EXIT_FAILURE);      // Exit child process with failure status
        } else if (process->pid < 0) {
            perror("fork failed");
            process->error = true;
            process->finished = true;
            return;
        }
        // Record the response time (if it was just started)
        if (process->is_default) {
            process->start_time = find_time();
            process->is_default = false;
        }
    } else {
        // Resume the process if it's already running
        printf("Resuming process: %d\n", process->pid);
        fflush(stdout);
        kill(process->pid, SIGCONT);
    }

    int status;
    uint64_t elapsed_time = 0;
    int process_finished = 0;
    uint64_t start_time = find_time();

    if (is_slice == 1) {  // Time slices are used
        while (elapsed_time < allotted_slice) {
            uint64_t current_time = find_time();
            elapsed_time = current_time - start_time;

            int ret = waitpid(process->pid, &status, WNOHANG);  // Non-blocking wait

            if (ret == process->pid) {
                // Process finished before the allotted time slice
                process->remaining_time = 0;
                process->finished = true;
                
                if (WIFEXITED(status)) {
                    if (WEXITSTATUS(status) == EXIT_SUCCESS) {
                        process->error = false;
                    } else {
                        process->error = true;
                    }
                } else {
                    process->error = true;  // Process did not exit normally
                }
                process_finished = 1;
                break;
            } else if (ret == -1 && errno == ECHILD) {
                // No child process found
                process->remaining_time = 0;
                process->finished = true;
                process->error = true;
                process_finished = 1;
                break;
            }

            usleep(1000);  // Sleep for a short time to prevent busy waiting
        }

        if (!process_finished) {
            // If the time slice was used up, stop the process
            if (kill(process->pid, SIGSTOP) == -1) {
                perror("Failed to stop process");
                process->error = true;
                process->remaining_time = 0;
                process->finished = true;
                return;
            }

            // Update remaining time
            uint64_t run_time = elapsed_time;
            if (run_time > allotted_slice) {
                run_time = allotted_slice;
            }

            process->remaining_time -= run_time;

            if (process->remaining_time == 0) {
                process->finished = true;
            }

            printf("New remaining time is: %lu ms\n", process->remaining_time);
            fflush(stdout);  // Ensure the print statement is flushed
        }
    } else {
        // No time slice, process executes fully
        waitpid(process->pid, &status, 0);  // Block until process finishes
        process->remaining_time = 0;
        process->finished = true;

        if (WIFEXITED(status)) {
            if (WEXITSTATUS(status) == EXIT_SUCCESS) {
                process->error = false;
            } else {
                process->error = true;  // Non-zero exit status indicates an error
            }
        } else {
            process->error = true;  // Process did not exit normally
        }
    }

    // Update burst time and occurrences
    uint64_t end_time = find_time();
    elapsed_time = end_time - start_time;

    // Update burst time based on actual run time
    if (process->is_default) {
        process->burst_time = elapsed_time;  // Set burst time based on first run
        process->is_default = false;
    } else {
        process->burst_time += elapsed_time;
    }

    // Update turnaround time
    if (process->finished) {
        process->turnaround_time = find_time() - process->arrival_time;  // Calculate turnaround time
    }

    if (process->finished && !process->error) {
        process->occurrences++;
    }

    // If elapsed time is longer than expected, adjust remaining time
    if (elapsed_time > allotted_slice) {
        process->remaining_time = elapsed_time;  // Set to elapsed time if process runs longer
        printf("Adjusting remaining time to: %lu ms (based on actual run)\n", process->remaining_time);
    }

    if (process->remaining_time == 0) {
        waitpid(process->pid, NULL, 0);  // Ensure child process has terminated
        process->pid = 0;  // Reset pid to 0 after the process finishes
    }
}

// Function to add new processes based on user input
void add_process(Process *processes, int *num_processes, char *input_command) {
    // Check if the process already exists (by command)
    for (int i = 0; i < *num_processes; ++i) {
        if (strcmp(processes[i].command, input_command) == 0) {
            // Create a new Process entry using historical data
            Process new_process = processes[i];
            new_process.command = strdup(input_command);
            if (processes[i].finished){
                new_process.burst_time = processes[i].burst_time;
                new_process.is_default = false;
            }else{
                new_process.is_default = true;
            }
            new_process.finished = false;
            new_process.error = false;
            new_process.remaining_time = new_process.burst_time;  // Use historical burst time
            new_process.pid = 0;
            new_process.arrival_time = find_time();  // Set arrival time for the new process
            new_process.response_time = -1;  // Reset response time
            
            processes[*num_processes] = new_process;
            (*num_processes)++;
            return;
        }
    }
    
    // If process does not exist, add a new one
    processes[*num_processes].command = strdup(input_command);
    processes[*num_processes].finished = false;
    processes[*num_processes].error = false;
    processes[*num_processes].burst_time = 1000;  // Default burst time: 1 second (1000 ms)
    processes[*num_processes].remaining_time = 1000;
    processes[*num_processes].occurrences = 0;
    processes[*num_processes].arrival_time = find_time();  // Set arrival time
    processes[*num_processes].response_time = -1;  // Initialize response time
    processes[*num_processes].pid = 0;
    processes[*num_processes].is_default = true;
    (*num_processes)++;
}

// Function to select the next process with the shortest burst time
Process *select_next_process(Process *processes, int num_processes) {
    Process *shortest_job = NULL;
    for (int i = 0; i < num_processes; ++i) {
        if (!processes[i].finished && (shortest_job == NULL || processes[i].burst_time < shortest_job->burst_time)) {
            shortest_job = &processes[i];
        }
    }
    return shortest_job;
}

// Function to save results to a CSV file
void save_results_to_csv(const char *filename, Process processes[], int num_processes) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    fprintf(file, "Command,Finished,Error,Burst Time,Turnaround Time,Waiting Time,Response Time\n");

    for (int i = 0; i < num_processes; ++i) {
        fprintf(file, "%s,%s,%s,%lu,%lu,%lu,%lu\n",
                processes[i].command,
                processes[i].finished ? (processes[i].error ? "No" : "Yes") : "No",  // Finished: Yes/No
                processes[i].error ? "Yes" : "No",  // Error: Yes/No only if finished, else N/A
                processes[i].burst_time,
                processes[i].turnaround_time,
                processes[i].waiting_time,
                processes[i].response_time);
    }

    fclose(file);
}

// Function to poll for new inputs and store them in a buffer
void poll_for_input(Process *processes, int *num_processes, bool *terminate_polling) {
    char input_command[50*sizeof(Process*)]; // 50 is the max no. of commands that can be added 
    printf("Enter a command (or 'exit' to finish): ");
    if (fgets(input_command, sizeof(input_command), stdin)) {
        input_command[strcspn(input_command, "\n")] = '\0';  // Remove newline
        if (strlen(input_command) > 0) {
            if (strcmp(input_command, "exit") == 0) {
                *terminate_polling = true; // if exit is entered, stops polling 
            } else {
                add_process(processes, num_processes, input_command); // otherwise, relevant process is made and added (SJF)
            }
        }
    }
}

// Main function to implement SJF scheduling
void ShortestJobFirst() {
    Process processes[100];  // Array to store processes
    int num_processes = 0;   // Number of processes
    bool terminate_polling = false;
    uint64_t curr = find_time();

    printf("Shortest Job First (SJF) Scheduler\n");

    // Get the first command from the user
    poll_for_input(processes, &num_processes, &terminate_polling);
    
    while (1) {
        // Poll for new input from the user at regular intervals
        poll_for_input(processes, &num_processes, &terminate_polling);
        
        // Select the next process to run (SJF)
        Process *next_process = select_next_process(processes, num_processes);
        if (next_process != NULL) {
            next_process->response_time = find_time() - next_process->arrival_time;
            run_process(next_process);  // Run the process with the shortest burst time
        }
        
        // Check if all processes are finished
        int completed_processes = 0;
        for (int i = 0; i < num_processes; ++i) {
            if (processes[i].finished) {
                completed_processes++;
            }
        }

        // Break the loop if all processes are finished and polling is terminated
        if (completed_processes == num_processes && terminate_polling) {
            printf("All processes are done\n");
            break;
        }
        
        usleep(500000);  // Sleep for 500ms to poll at regular intervals
    }
    
    printf("All processes completed\n");
    save_results_to_csv("result_online_SJF.csv", processes, num_processes);
}

#define QUEUE_SIZE 50

int which_queue(Process *proc, int quantum0, int quantum1, int quantum2){
    // returns which queue the process should be added to
    if (proc->burst_time == 1000){
        // add to queue1
        return 1;
    } else if (proc->burst_time <= quantum0){
        return 0;
    } else if ((quantum0<proc->burst_time)&&(proc->burst_time<=quantum1)){
        return 1;
    }else{
        return 2;
    }
}

void MultiLevelFeedbackQueue(int quantum0, int quantum1, int quantum2, int boostTime) {
    int completed = 0;
    Process processes[100];
    int num_processes = 0;
    bool terminate_polling = false;

    printf("Multi-Level Feedback Queue\n");

    Process **queue0 = calloc(QUEUE_SIZE, sizeof(Process*));
    Process **queue1 = calloc(QUEUE_SIZE, sizeof(Process*));
    Process **queue2 = calloc(QUEUE_SIZE, sizeof(Process*));

    if (!queue0 || !queue1 || !queue2) {
        perror("Failed to allocate memory for queues");
        exit(EXIT_FAILURE);
    }

    // Initialize the queues 
    int q0_front = 0, q0_rear = 0;
    int q1_front = 0, q1_rear = 0;
    int q2_front = 0, q2_rear = 0;

    // base defines the baseline time 
    uint64_t base = find_time();
    uint64_t curr = base;
    uint64_t last_boost = base;

    while (!terminate_polling || (completed < num_processes)) {
        // Poll for new input
        if (!terminate_polling) {
            printf("Polling for input...\n"); // Debug statement
            poll_for_input(processes, &num_processes, &terminate_polling);
            if (num_processes > 0) {
                Process *proc = &processes[num_processes-1];
                int queue_num = which_queue(proc, quantum0, quantum1, quantum2);
                if (queue_num==0){
                    if (q0_rear < QUEUE_SIZE) {
                        queue0[q0_rear++] = &processes[num_processes - 1];
                        printf("New process added to queue1. Total processes: %d\n", num_processes);
                    } else {
                        printf("Queue1 is full. Cannot add new process.\n"); // Debug statement
                    }
                } else if (queue_num == 1){
                    if (q1_rear < QUEUE_SIZE) {
                        queue1[q1_rear++] = &processes[num_processes - 1];
                        printf("New process added to queue1. Total processes: %d\n", num_processes);
                    } else {
                        printf("Queue1 is full. Cannot add new process.\n"); // Debug statement
                    }
                } else {
                    if (q2_rear < QUEUE_SIZE) {
                        queue2[q2_rear++] = &processes[num_processes - 1];
                        printf("New process added to queue1. Total processes: %d\n", num_processes);
                    } else {
                        printf("Queue1 is full. Cannot add new process.\n"); // Debug statement
                    }
                }
            }
        }

        // Update current time
        curr = find_time();

        // Apply boost if necessary
        if (curr - last_boost >= boostTime) {
            printf("Applying boost at time: %lu\n", curr - base);

            // Move processes from queue1 and queue2 to queue0
            while (q1_front < q1_rear && q0_rear < QUEUE_SIZE) {
                queue0[q0_rear++] = queue1[q1_front++];
            }
            while (q2_front < q2_rear && q0_rear < QUEUE_SIZE) {
                queue0[q0_rear++] = queue2[q2_front++];
            }

            q1_rear = q1_front;
            q2_rear = q2_front;
            last_boost = curr;
        }

        // Process high priority queue
        if (q0_front < q0_rear) {
            Process *process = queue0[q0_front++];
            run_process2(process, quantum0, 1);
            if (process->remaining_time > 0 && q1_rear < QUEUE_SIZE) {
                queue1[q1_rear++] = process;
            } else {
                completed++;
            }
            printf("Processed from queue0. Completed: %d\n", completed);

            // Poll for new input after processing
            if (!terminate_polling) {
                printf("Polling for input after queue0 processing...\n"); // Debug statement
                poll_for_input(processes, &num_processes, &terminate_polling);
                if (num_processes > 0 && q1_rear < QUEUE_SIZE) {
                    queue1[q1_rear++] = &processes[num_processes - 1];
                    printf("New process added to queue1 during queue0 processing. Total processes: %d\n", num_processes);
                }
            }
        }

        // Process medium priority queue
        else if (q1_front < q1_rear) {
            Process *process = queue1[q1_front++];
            run_process2(process, quantum1, 1);
            if (process->remaining_time > 0 && q2_rear < QUEUE_SIZE) {
                queue2[q2_rear++] = process;
            } else {
                completed++;
            }
            printf("Processed from queue1. Completed: %d\n", completed);

            // Poll for new input after processing
            if (!terminate_polling) {
                printf("Polling for input after queue1 processing...\n"); // Debug statement
                poll_for_input(processes, &num_processes, &terminate_polling);
                if (num_processes > 0 && q1_rear < QUEUE_SIZE) {
                    queue1[q1_rear++] = &processes[num_processes - 1];
                    printf("New process added to queue1 during queue1 processing. Total processes: %d\n", num_processes);
                }
            }
        }

        // Process low priority queue
        else if (q2_front < q2_rear) {
            Process *process = queue2[q2_front++];
            run_process2(process, quantum2, 0);
            if (process->remaining_time > 0 && q2_rear < QUEUE_SIZE) {
                queue2[q2_rear++] = process;
            } else {
                completed++;
            }
            printf("Processed from queue2. Completed: %d\n", completed);

            // Poll for new input after processing
            if (!terminate_polling) {
                printf("Polling for input after queue2 processing...\n"); // Debug statement
                poll_for_input(processes, &num_processes, &terminate_polling);
                if (num_processes > 0 && q1_rear < QUEUE_SIZE) {
                    queue1[q1_rear++] = &processes[num_processes - 1];
                    printf("New process added to queue1 during queue2 processing. Total processes: %d\n", num_processes);
                }
            }
        }

        // Sleep to prevent tight looping
        usleep(500000);
    }

    save_results_to_csv("result_online_MultiLevelFeedbackQueue.csv", processes, num_processes);

    // Final clean-up
    while (q0_front < q0_rear) {
        Process *process = queue0[q0_front++];
        run_process2(process, quantum0, 1);
    }
    while (q1_front < q1_rear) {
        Process *process = queue1[q1_front++];
        run_process2(process, quantum1, 1);
    }
    while (q2_front < q2_rear) {
        Process *process = queue2[q2_front++];
        run_process2(process, quantum2, 0);
    }

    free(queue0);
    free(queue1);
    free(queue2);

    printf("All processes completed\n");
}