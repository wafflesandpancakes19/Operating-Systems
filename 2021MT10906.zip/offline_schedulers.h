#pragma once

//Can include any other headers as needed
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/time.h>
#include <stdbool.h>
#include <fcntl.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>

typedef struct {

    //This will be given by the tester function this is the process command to be scheduled
    char *command;

    //Temporary parameters for your usage can modify them as you wish
    bool finished;  //If the process is finished safely
    bool error;    //If an error occurs during execution
    uint64_t start_time;
    uint64_t completion_time;
    uint64_t turnaround_time;
    uint64_t waiting_time;
    uint64_t response_time;
    uint64_t burst_time;
    uint64_t arrival_time;
    uint64_t remaining_time;
    pid_t pid; // process id for the command that has been running (in order to resume the process)
    bool started; 
    int process_id;
    int occurrences;

} Process;

// Function prototypes
void FCFS(Process p[], int n);
void RoundRobin(Process p[], int n, int quantum);
void MultiLevelFeedbackQueue(Process p[], int n, int quantum0, int quantum1, int quantum2, int boostTime);

// HELPER FUNCTIONS COMMON TO THE DIFFERENT SCHEDULERS 

// Function to get the current time in milliseconds
uint64_t find_time() {
    // gets the current time in milliseconds 
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (uint64_t)(tv.tv_sec) * 1000 + (tv.tv_usec) / 1000;
}

void run_process(Process *process, uint64_t time_slice, int is_slice) {
    printf("Running command: %s\n", process->command);
    printf("Time slice: %lu ms\n", time_slice);

    uint64_t start_time = find_time();
    uint64_t allotted_slice = (process->remaining_time > 0 && process->remaining_time < time_slice) 
                              ? process->remaining_time : time_slice;

    if (process->pid == 0) {
        // Fork a new process if not already running
        process->pid = fork();

        if (process->pid == 0) {
            // Child process runs the command
            execl("/bin/sh", "sh", "-c", process->command, (char *)NULL);
            // If execl fails, it will return here
            perror("execl failed");  // Print specific error
            exit(EXIT_FAILURE);      // Exit child process with failure status
        } else if (process->pid < 0) {
            perror("fork failed");
            process->error = true;
            process->finished = true;
            return;
        }
    } else {
        // Resume the process if it's already running
        kill(process->pid, SIGCONT);
    }

    int status;
    uint64_t elapsed_time = 0;
    int process_finished = 0;

    if (is_slice == 1) {  // Time slices are used
        while (elapsed_time < allotted_slice) {
            uint64_t current_time = find_time();
            elapsed_time = current_time - start_time;

            int ret = waitpid(process->pid, &status, WNOHANG);  // Non-blocking wait

            if (ret == process->pid) {
                // Process is done
                process->remaining_time = 0;
                process_finished = 1;

                if (WIFEXITED(status)) {
                    if (WEXITSTATUS(status) == EXIT_SUCCESS) {
                        process->finished = true;
                        process->error = false;
                    } else {
                        process->finished = true;
                        process->error = true;  // Non-zero exit status indicates an error
                    }
                } else {
                    process->finished = true;
                    process->error = true;  // Process did not exit normally
                }
                break;
            } else if (ret == -1 && errno == ECHILD) {
                // No child process found
                process->remaining_time = 0;
                process->finished = true;
                process->error = true;
                process_finished = 1;
                break;
            }

            usleep(1000);  // Sleep for a short time to prevent busy waiting
        }

        if (!process_finished) {
            // If the time slice was used up, stop the process
            printf("Stopping process: %d\n", process->pid);
            kill(process->pid, SIGSTOP);  // Pause the process
            process->remaining_time -= elapsed_time;
        }
    } else {
        // No time slice, process executes fully
        waitpid(process->pid, &status, 0);  // Block until process finishes
        process->remaining_time = 0;
        process_finished = 1;

        if (WIFEXITED(status)) {
            if (WEXITSTATUS(status) == EXIT_SUCCESS) {
                process->finished = true;
                process->error = false;
            } else {
                process->finished = true;
                process->error = true;  // Non-zero exit status indicates an error
            }
        } else {
            process->finished = true;
            process->error = true;  // Process did not exit normally
        }
    }

    // Update burst time and occurrences
    uint64_t end_time = find_time();
    elapsed_time = end_time - start_time;
    
    if (process->burst_time == 0) {
        process->burst_time = elapsed_time;  // Set burst time based on first run
    } else {
        //process->burst_time = ((process->burst_time * (process->occurrences - 1)) + elapsed_time) / process->occurrences;
        process->burst_time = process->burst_time+elapsed_time;
    }

    process->occurrences++;

    if (process->remaining_time == 0) {
        waitpid(process->pid, NULL, 0);  // Ensure child process has terminated
        process->pid = 0;  // Reset pid to 0 after the process finishes
    }
}

// Function to save results to CSV
void save_results_to_csv(const char *filename, Process processes[], int num_processes) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    fprintf(file, "Command,Finished,Error,Burst Time,Turnaround Time,Waiting Time,Response Time\n");

    for (int i = 0; i < num_processes; ++i) {
    fprintf(file, "%s,%s,%s,%lu,%lu,%lu,%lu\n",
            processes[i].command,
            processes[i].finished ? (processes[i].error ? "No" : "Yes") : "No",  // Finished: Yes/No
            processes[i].error ? "Yes": "No",  // Error: Yes/No only if finished, else N/A
            processes[i].burst_time,
            processes[i].turnaround_time,
            processes[i].waiting_time,
            processes[i].response_time);
}

    fclose(file);
}

// FIRST COME FIRST SERVE SCHEDULER 

void FCFS(Process p[], int n) {
    // this algorithm essentially executes the process that arrives first, first
    // p is the list of processes, and n is the number of processes

    uint64_t curr = 0; // keeps track of the time at the moment 
    uint64_t arriv = 0; // we assume that all of them arrive at the same time since it was fed at the time of compilation as a list 

    for (int i = 0; i < n; ++i) {
        p[i].arrival_time = arriv;
        p[i].response_time = curr - p[i].arrival_time;
        // p[i].remaining_time = 5000;  // Assume a default remaining time for all processes, replace with actual if known
        p[i].pid = 0;
        p[i].burst_time = 0;

        run_process(&p[i], 1000, 0);  // Run the entire process
        printf("burst time: %lu \n", p[i].burst_time);
        printf("was there an error? %s \n", p[i].error? "Yes":"No");

        curr = curr + p[i].burst_time;
        p[i].completion_time = curr;
        p[i].turnaround_time = p[i].completion_time - p[i].arrival_time;
        p[i].waiting_time = p[i].turnaround_time - p[i].burst_time;
        // p[i].finished = true;
        // p[i].error = false;

        printf("%s|%lu|%lu\n", p[i].command, p[i].arrival_time, p[i].completion_time);
    }

    save_results_to_csv("result_offline_FCFS.csv", p, n);
}

void RoundRobin(Process p[], int n, int quantum) {
    int completed = 0;
    uint64_t arriv = find_time();
    uint64_t curr = arriv;
    int i = 0;
    for (int j = 0; j < n; ++j) {
        p[j].burst_time = 0;  // No default burst time
        p[j].remaining_time = 0;  // Remaining time will be calculated dynamically
        p[j].pid = 0;
        p[j].response_time = -1;
        p[j].finished = false;  // Reset finished status for all processes
        p[j].arrival_time = arriv;
        //printf("arrival time is: %lu and current time is: %lu \n", p[j].arrival_time, curr);
        //printf("command: %s \n", p[j].command);
    }

    while (completed < n) {
        Process *proc = &p[i];

        // Only run processes that are not finished
        if (!proc->finished) {
            if (proc->response_time == -1 && proc->arrival_time <= curr) {
                printf("arrival time is: %lu and current time is: %lu \n", proc->arrival_time, curr);
                proc->response_time = curr - proc->arrival_time;
            }

            uint64_t time_before = find_time();

            run_process(proc, quantum, 1);

            uint64_t time_after = find_time();
            uint64_t actual_time_used = time_after - time_before;

            curr += actual_time_used;

            // If the process is finished, update its times
            if (proc->remaining_time == 0) {
                proc->completion_time = curr-arriv;
                proc->turnaround_time = proc->completion_time;
                proc->waiting_time = proc->turnaround_time - proc->burst_time;
                completed++;
            }

            printf("Process %s | Time slice: %u ms | Actual time used: %lu ms\n", proc->command, quantum, actual_time_used);
        }

        // Move to the next process in the round-robin order
        i = (i + 1) % n;
    }

    save_results_to_csv("result_offline_RoundRobin.csv", p, n);
}

void MultiLevelFeedbackQueue(Process p[], int n, int quantum0, int quantum1, int quantum2, int boostTime) {
    int completed = 0; // Counts the number of processes that have been completed
    uint64_t curr = 0;
    uint64_t arriv = find_time();
    uint64_t last_boost = arriv;  // Tracks the last time the boost took place

    // Initialize the queues that will store process pointers
    Process **queue0 = malloc(n * sizeof(Process*));  // High priority
    Process **queue1 = malloc(n * sizeof(Process*));  // Medium priority
    Process **queue2 = malloc(n * sizeof(Process*));  // Low priority
    int q0_front = 0, q0_rear = 0, q1_front = 0, q1_rear = 0, q2_front = 0, q2_rear = 0;

    // Initialize processes and assign them to queue 1 (medium priority initially)
    for (int i = 0; i < n; ++i) {
        p[i].pid = 0;  // Process is not yet running
        p[i].response_time = -1;  // Response time not yet set
        p[i].arrival_time = arriv;
        p[i].remaining_time = 0; // Set remaining time to burst time
        queue0[q0_rear++] = &p[i];  // Add process pointers to the medium-level priority queue
    }

    while (completed < n) {
        curr = find_time();  // Update current time

        // Check if it's time to apply the priority boost
        if (curr - last_boost >= boostTime) {
            printf("Applying boost at time: %lu\n", curr - arriv);

            // Move all processes from queue1 and queue2 to queue0
            while (q1_front < q1_rear) {
                queue0[q0_rear++] = queue1[q1_front++];  // Move to high priority queue
            }
            q1_front = 0; q1_rear = 0;  // Reset queue 1

            while (q2_front < q2_rear) {
                queue0[q0_rear++] = queue2[q2_front++];  // Move to high priority queue
            }
            q2_front = 0; q2_rear = 0;  // Reset queue 2

            last_boost = curr;  // Update last boost time
        }

        // Process high priority queue (small time slice)
        if (q0_front < q0_rear) {
            Process *proc = queue0[q0_front++];  // Fetch process from the queue
            if (proc->response_time == -1) {
                proc->response_time = curr - proc->arrival_time;
            }

            // Run process and calculate the actual time used
            uint64_t time_before = find_time();
            run_process(proc, quantum0, 1);
            uint64_t time_after = find_time();
            uint64_t actual_time_used = time_after - time_before;
            proc->burst_time = proc->burst_time+actual_time_used;

            curr += actual_time_used;

            if (proc->remaining_time == 0) {
                // Process completed
                proc->completion_time = curr - arriv;
                proc->turnaround_time = proc->completion_time;
                proc->waiting_time = proc->turnaround_time - proc->burst_time;
                completed++;
            } else {
                queue1[q1_rear++] = proc;  // Demote to medium priority queue
            }

            printf("%s | Completion Time: %lu\n", proc->command, curr - arriv);
        }

        // Process medium priority queue (medium time slice)
        else if (q1_front < q1_rear) {
            Process *proc = queue1[q1_front++];  // Fetch process from the queue

            uint64_t time_before = find_time();
            run_process(proc, quantum1, 1);
            uint64_t time_after = find_time();
            uint64_t actual_time_used = time_after - time_before;

            curr += actual_time_used;

            if (proc->remaining_time == 0) {
                // Process completed
                proc->completion_time = curr - arriv;
                proc->turnaround_time = proc->completion_time;
                proc->waiting_time = proc->turnaround_time - proc->burst_time;
                completed++;
            } else {
                queue2[q2_rear++] = proc;  // Demote to low priority queue
            }

            printf("%s | Completion Time: %lu\n", proc->command, curr - arriv);
        }

        // Process low priority queue (large time slice)
        else if (q2_front < q2_rear) {
            Process *proc = queue2[q2_front++];  // Fetch process from the queue

            uint64_t time_before = find_time();
            run_process(proc, quantum2, 1);
            uint64_t time_after = find_time();
            uint64_t actual_time_used = time_after - time_before;

            curr += actual_time_used;

            if (proc->remaining_time == 0) {
                // Process completed
                proc->completion_time = curr - arriv;
                proc->turnaround_time = proc->completion_time;
                proc->waiting_time = proc->turnaround_time - proc->burst_time;
                completed++;
            } else {
                queue2[q2_rear++] = proc;  // Remain in low priority queue
            }

            printf("%s | Completion Time: %lu\n", proc->command, curr - arriv);
        }
    }

    // Print final results and save to CSV
    printf("Number of completed processes: %d\n", completed);

    for (int i = 0; i < n; ++i) {
        printf("Process %s - Completion Time: %lu, Turnaround Time: %lu, Waiting Time: %lu\n",
               p[i].command, p[i].completion_time, p[i].turnaround_time, p[i].waiting_time);
    }

    save_results_to_csv("result_offline_MultiLevelFeedbackQueue.csv", p, n);

    free(queue0);
    free(queue1);
    free(queue2);
}